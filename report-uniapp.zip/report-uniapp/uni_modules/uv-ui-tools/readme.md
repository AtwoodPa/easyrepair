## uv-ui-tools 工具集

> **组件名：uv-ui-tools**

uv-ui 工具集成，包括网络Http请求、便捷工具、节流防抖、对象操作、时间格式化、路由跳转、全局唯一标识符、规则校验等等。

需要在自己的项目中使用请参考[扩展配置](https://www.uvui.cn/components/setting.html)。

### <a href="https://www.uvui.cn/js/intro.html" target="_blank">查看文档</a>

### [完整示例项目下载 | 关注更多组件](https://ext.dcloud.net.cn/plugin?name=uv-ui)

#### 如使用过程中有任何问题，或者您对uv-ui有一些好的建议，欢迎加入 uv-ui 交流群：<a href="https://ext.dcloud.net.cn/plugin?id=12287" target="_blank">uv-ui</a>、<a href="https://www.uvui.cn/components/addQQGroup.html" target="_blank">官方QQ群</a>
