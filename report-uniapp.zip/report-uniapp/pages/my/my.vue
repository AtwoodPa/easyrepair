<template>
	<view class="user_center"> <!-- 用户信息开始 -->
		<view class="user_info_bg">
			<view class="user_info_wrap">
				<!--获取头像-->
				<button class="user_image" open-type="chooseAvatar" style="border: none;" plain
					@chooseavatar="onChooseAvatar">
					<image :src="userInfo.avatarUrl"></image>
				</button>
				<view class="user_name">
					<!-- {{userInfo.nickName}} -->
					<input type="nickname" placeholder="请输入昵称" v-model="userInfo.nickName" @blur="onChangeNickName" />
				</view>
			</view>
		</view>
		<!-- 用户信息结束 --> <!-- 用户菜单开始 -->
		<view class="user_menu_wrap">
			<view class="user_menu_item" @click="goMyReport(userInfo.nickName)"> <text>我的报修</text> </view>
			
			<view class="user_menu_item" @click="goJoinVoteList()"> <text>关于我们</text> </view>
		</view> <!-- 用户菜单结束 --> <!-- 用户信息修改开始 -->
		<view class="user_info_modify_wrap">
			<!-- <view class="user_info_modify_wrap_item" @click="goAuthor()"> <text>联系我</text> </view> -->
			<view class="user_info_modify_wrap_item" @click="callPhone()"> <text>技术顾问 : 19852815418</text> </view>
		</view> <!-- 用户信息修改结束 -->
	</view>
</template>
<script>
	import {
		getBaseUrl,
		requestUtil
	} from '../../utils/requestUtil'
	import {
		isEmpty
	} from "../../utils/StringUtil.js"
	export default {
		data() {
			return {
				userInfo: {
					nickName: '',
					avatarUrl: ''
				},
				baseUrl: ''
			}
		},
		onShow() {
			this.getUserInfo()
			this.baseUrl = getBaseUrl();
		},
		methods: {
			goMyReport: function(nickName){
				uni.navigateTo({
					url:"/pages/myreport/myreport?nickName=" +nickName 
				})
			},
			getUserInfo: async function() {
				const result = await requestUtil({
					url: "/user/getUserInfo",
					method: 'get'
				});
				console.log("result=" + result.currentUser);
				this.userInfo = result.currentUser
			},
			onChangeNickName: async function(e) {
				console.log(e.detail.value);
				let nickName = e.detail.value;
				if (!isEmpty(nickName)) {
					const result = await requestUtil({
						url: "/user/updateNickName",
						data: {
							nickName: nickName
						},
						method: 'post'
					});
				}
			},
			onChooseAvatar: async function(e) {
				console.log(e.detail.avatarUrl);
				var _that = this;
				// 调用uni的文件上传方法
				uni.uploadFile({
					header: {
						token: uni.getStorageSync("token")
					},
					url: getBaseUrl() + "/user/updateUserImage",
					filePath: e.detail.avatarUrl,
					name: "userImage",
					success(res) {
						console.log("res:"+res.data)
						// 回显设置头像
						_that.userInfo.avatarUrl = res.data
					}
				})
			},
			
			callPhone: function() {
				wx.makePhoneCall({
					// 19852815418
					phoneNumber: '19852815418' //仅为示例，并非真实的电话号码
				})
			}

		}
	}
</script>
<style lang="scss">
	.user_center {
		.user_info_bg {
			position: relative;
			height: 40vh;
			background-color: #0066FF;
			.user_info_wrap {
				position: relative;
				top: 30%;
				text-align: center;
				.user_image {
					image {
						width: 150rpx;
						height: 150rpx;
						border-radius: 50%;
					}
				}
				.user_name {
					display: flex;
					flex-direction: column;
					justify-content: center;
					color: #fff;
					// padding-left: 20rpx;
					// padding-bottom: 15rpx;
				}
			}
		}

		.user_menu_wrap {
			margin: 15rpx;
			margin-top: 20rpx;
			background-color: #fff;

			.user_menu_item {
				padding: 20rpx;
				padding-left: 35rpx;
				border-bottom: 5rpx solid #F6F6F4;
			}
		}

		.user_info_modify_wrap {
			margin: 15rpx;
			margin-top: 20rpx;
			background-color: #fff;
			padding: 20rpx 0;
			padding-left: 35rpx;
		}
	}
</style>