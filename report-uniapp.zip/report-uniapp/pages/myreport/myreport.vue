<template>
	<view class="content">
		<!-- 日期选择器，根据所选日期来筛选报修数据 -->
		<uni-datetime-picker v-model="datetimerange" type="datetimerange" rangeSeparator="至" />
		<uv-sticky bgColor="#fff" >
		    <uv-tabs
		     lineWidth="80" 
		     itemStyle="padding-left: 58rpx; padding-right: 55rpx; height: 80rpx;"
		     :list="list" 
		     @click="click">
			 </uv-tabs>
		  </uv-sticky>
		  
		  <uv-list
		  			@scrolltolower="scrolltolower"
		  		>
				<!-- .. -->
				
					<uv-list-item
						v-for="(item, index) in reports"
						:key="index"
					>
						<view @click="goReportDetail(item.id)">
							<uv-cell
								:title="`列表长度-${index + 1}`"
							>
								<template v-slot:icon>
									<!-- <image :src="this.baseUrl+'/image/userAvatar/' + userInfo.avatarUrl"></image> -->
									<view class="list">
										<view class="left">
											<uv-avatar
												class="avatar"
												shape="square"
												size="80"
												:src="item.image"
												customStyle="margin: 5rpx 5rpx 5rpx 5rpx"
											></uv-avatar>
										</view>
										<view class="right">
											<view class="username">
												申请人 :  {{item.username}}
											</view>
											<view class="type">
												设备类型 :  {{item.equtype}}
											</view>
											<view class="date">
												申请日期 :  {{item.createTime}}
											</view>
										</view>
										
									</view>
									
								</template>
							</uv-cell>
						</view>
						<view class="action">
							
							<view class="item"  @click="actionSet(item.id)">
								<view class="voteManageItem">&#xeb61;</view>
								<text class="text">管理</text>
							</view>
						</view>
						
					</uv-list-item>
				
		  			
					<!-- .. -->
		  		</uv-list>
	</view>
</template>

<script>
	import { getBaseUrl,requestUtil } from '../../utils/requestUtil'
	export default {
		data() {
			return {
				baseUrl:'',
				datetimerange: [],
				list: [
				{
					name: '全部',
				}, 
				{
					name: '新报修',
				}, 
				{
					name: '维修中'
				},
				{
					name: '已完成'
				}
				],
				// 所有维修记录数组
				reports:[]
			}
		},
		watch: {
			async datetimerange(newval) {
							console.log('范围选:', this.datetimerange);
							console.log('start:', this.datetimerange[0]);
							console.log('end:', this.datetimerange[1]);
							const result = await requestUtil({
								url: "/api/v1/report/getReportByTimeArrays/"+this.datetimerange[0]+"/"+this.datetimerange[1],
								method: "get",
								
							});
							console.log("result="+ result.allReports);
							this.reports = result.allReports
							
			}
		},
		methods: {
			actionSet: async function(id) {
				uni.showActionSheet({
					itemList: ['删除当前报修记录'],
					success: (res) => {
						let _id = id;
						if (res.tapIndex == 0) {
							console.log("remove operation");
							uni.showModal({
								title: "系统提示",
								content: "您确定要删除当前报修记录吗？",
								success: async (res2) => {
									if (res2.confirm) {
										const result = await requestUtil({
											url: "/api/v1/report/remove/" + _id,
											method: "get"
										});
										if (result.code == 200) {
											uni.showToast({
												icon: "success",
												title: "删除成功",
												duration: 2000
											})
			
											// 跳转到首页
											uni.switchTab({
												url: "/pages/index/index"
											})
										}
			
									}
								}
							})
						}
					}
				})
			},
			// tabs 切换item时，重新加载list列表内容
			async click(item) {
				console.log('item', item);
				console.log('index', item.index);
				const result = await requestUtil({url:"/api/v1/report/getReportsByStatus/" + item.index,method:'get'});
				console.log(result);
				console.log("result="+ result.allReports);
				this.reports = result.allReports
			},
			getAllReportList: async function(){
				const result = await requestUtil({url:"/api/v1/report/getAllReports",method:'get'});
				console.log("result="+result.allReports);
				this.reports = result.allReports
			},
			scrolltolower: function(){
				this.getAllReportList()
			},
			goHomePage: function() {
				uni.switchTab({
					url: "/pages/index/index"
				})
			},
			goReportDetail(reportId){
				uni.navigateTo({
					url:"/pages/detail/detail?id="+reportId
				})
			}
		},
		onShow() {
			this.getAllReportList();
		},
		onLoad() {
			this.getAllReportList();
			this.baseUrl = getBaseUrl();
		},
	}
</script>

<style lang="scss">
	@import "/common/css/iconfont.css";
	.action {
		
		margin-top: 10rpx;
	
		padding: 10px;
		
		border-radius: 10px;
		background-color: white;
		display: flex;
		text-align: center;
		width: 100%;
		.item {
			flex: 1;
			text-align: center;
			font-size: 12px;
		}
	}
	
.views{
		height: 500rpx;
		margin-top: 20rpx;
	}
	.content {
		
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
		.list{
			background-color: white;
			border-radius: 10px;
			display: flex;
			flex-direction: row;
			margin-top: 10rpx;
			height: 160rpx;
			.left{
				margin: 0;height: 300rpx;
			}
			.right{
				flex: 1;
				height: 300rpx;
				.username{
					margin-top: 8rpx;
				}
				.type{
					margin-top: 10rpx;
					
				}
				.date{
					margin-top: 10rpx;
				}
			}
		}
	}

	.logo {
		height: 200rpx;
		width: 200rpx;
		margin-top: 200rpx;
		margin-left: auto;
		margin-right: auto;
		margin-bottom: 50rpx;
	}

	.text-area {
		display: flex;
		justify-content: center;
	}

	.title {
		font-size: 36rpx;
		color: #8f8f94;
	}
</style>
