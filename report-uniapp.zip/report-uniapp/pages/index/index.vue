<template>
	<view class="content">
		<uv-sticky bgColor="#fff" >
		    <uv-tabs
		     lineWidth="80" 
		     itemStyle="padding-left: 58rpx; padding-right: 55rpx; height: 80rpx;"
		     :list="list" 
		     @click="click">
			 </uv-tabs>
		  </uv-sticky>
		  
		  <uv-list
		  			@scrolltolower="scrolltolower"
		  		>
				<!-- .. -->
				
					<uv-list-item
						v-for="(item, index) in reports"
						:key="index"
					>
						<view @click="goReportDetail(item.id)">
							<uv-cell
								:title="`列表长度-${index + 1}`"
							>
								<template v-slot:icon>
									<!-- <image :src="this.baseUrl+'/image/userAvatar/' + userInfo.avatarUrl"></image> -->
									<view class="list">
										<view class="left">
											<uv-avatar
												class="avatar"
												shape="square"
												size="80"
												:src="item.image"
												customStyle="margin: 3rpx 5rpx 3rpx 5rpx"
											></uv-avatar>
										</view>
										<view class="right">
											<view class="username">
												申请人 :  {{item.username}}
											</view>
											<view class="type">
												设备类型 :  {{item.equtype}}
											</view>
											<view class="date">
												申请日期 :  {{item.createTime}}
											</view>
										</view>
									</view>
									
								</template>
							</uv-cell>
						</view>
						
						
					</uv-list-item>
				
		  			
					<!-- .. -->
		  		</uv-list>
	</view>
</template>

<script>
	import { getBaseUrl,requestUtil } from '../../utils/requestUtil'
	export default {
		data() {
			return {
				baseUrl:'',
				list: [
				{
					name: '全部',
				}, 
				{
					name: '新报修',
				}, 
				{
					name: '维修中'
				},
				{
					name: '已完成'
				}
				],
				// 所有维修记录数组
				reports:[]
			}
		},
		onShow() {
			this.getAllReportList();
		},
		onLoad() {
			this.getAllReportList();
			this.baseUrl = getBaseUrl();
		},
		methods: {
			// tabs 切换item时，重新加载list列表内容
			async click(item) {
				console.log('item', item);
				console.log('index', item.index);
				const result = await requestUtil({url:"/api/v1/report/getReportsByStatus/" + item.index,method:'get'});
				console.log(result);
				console.log("result="+ result.allReports);
				this.reports = result.allReports
			},
			getAllReportList: async function(){
				const result = await requestUtil({url:"/api/v1/report/getAllReports",method:'get'});
				console.log("result="+result.allReports);
				this.reports = result.allReports
			},
			scrolltolower: function(){
				this.getAllReportList()
			},
			goReportDetail(reportId){
				uni.navigateTo({
					url:"/pages/detail/detail?id="+reportId
				})
			}
		}
	}
</script>

<style lang="scss">
	.views{
		height: 500rpx;
		margin-top: 20rpx;
	}
	.content {
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
		.list{
			display: flex;
			flex-direction: row;
			margin-top: 10rpx;
			.left{
				margin: 0;
			}
			.right{
				flex: 1;
				.username{
					margin-top: 8rpx;
				}
				.type{
					margin-top: 10rpx;
					
				}
				.date{
					margin-top: 10rpx;
				}
			}
		}
	}

	.logo {
		height: 200rpx;
		width: 200rpx;
		margin-top: 200rpx;
		margin-left: auto;
		margin-right: auto;
		margin-bottom: 50rpx;
	}

	.text-area {
		display: flex;
		justify-content: center;
	}

	.title {
		font-size: 36rpx;
		color: #8f8f94;
	}
</style>