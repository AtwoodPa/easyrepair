<template>
	<view class="container">
		<uni-section title="设备报修表单" type="line">
			<view class="example">
				<!-- 基础表单校验 -->
				<uni-forms ref="valiForm" :rules="rules" :modelValue="valiFormData">
					<!-- 1申请人姓名 -->
					<uni-forms-item label="申请人" required name="username">
						<uni-easyinput v-model="valiFormData.username" placeholder="请输入申请人" />
					</uni-forms-item>
					<!-- 2联系电话 -->
					<uni-forms-item label="联系方式" required name="phone">
						<uni-easyinput v-model="valiFormData.phone" placeholder="请输入联系方式" />
					</uni-forms-item>
					<!-- 3报修地址 -->
					<uni-forms-item label="报修地址" required name="address">
						<uni-easyinput v-model="valiFormData.address" placeholder="请输入报修地址" />
					</uni-forms-item>
					<!-- 4设备名称 -->
					<uni-forms-item label="设备名称" required name="equname">
						<uni-easyinput v-model="valiFormData.equname" placeholder="请输入设备名称" />
					</uni-forms-item>
					<!-- 5设备类型 -->
					<uni-forms-item label="设备类型" required name="equtype">
						<uni-data-select v-model="valiFormData.equtype" :localdata="range"
							@change="change"></uni-data-select>
					</uni-forms-item>
					<!-- 6故障描述 -->
					<uni-forms-item label="故障描述" required name="description">
						<uni-easyinput type="textarea" v-model="valiFormData.description" placeholder="请输入故障描述" />
					</uni-forms-item>
					<!-- 7故障图片 -->
					<uni-forms-item label="故障图片" required name="image">
						<view class="cover_img">
							<view class="upload_img">
								<uni-file-picker @select="selectReportFileFunc($event)" :auto-upload="false" limit="1"
									:del-icon="true" disable-preview file-mediatype="image"
									:imageStyles="reportImageStyles">
									<view class="upload">
										<text class="uploadImg">&#xe727;</text>
									</view>
								</uni-file-picker>
							</view>
						</view>
					</uni-forms-item>

				</uni-forms>

				<button type="primary" class="submit_btn" @click="submit('valiForm')">提交</button>
			</view>
		</uni-section>
	</view>
</template>


<script>
	import {
		getBaseUrl,
		requestUtil
	} from "../../utils/requestUtil.js"
	import {
		isEmpty
	} from "../../utils/StringUtil.js"
	import {
		timeFormat
	} from "../../utils/dateUtil.js"
	export default {
		data() {
			return {
				// 当前登录的微信用户
				userInfo: {
					nickName: '',
					avatarUrl: ''
				},
				baseUrl: '',
				reportImageStyles: {
					width: "700rpx",
					height: "400rpx",
					border: false
				},
				value: 0,
				range: [{
						value: 0,
						text: "电脑"
					},
					{
						value: 1,
						text: "显示器"
					},
					{
						value: 2,
						text: "投影仪"
					},
					{
						value: 3,
						text: "其他"
					},
				],
				// 校验表单数据
				valiFormData: {
					username: '',
					phone: '',
					address: '',
					equname: '',
					equtype: '',
					description: '',
					image: '',
					status: 1
				},
				// 校验规则
				rules: {
					username: {
						rules: [{
							required: true,
							errorMessage: '姓名不能为空'
						}]
					},
					phone: {
						rules: [{
							required: true,
							errorMessage: '联系方式不能为空'
						}, {
							format: 'number',
							errorMessage: '联系方式只能输入数字'
						}]
					},
					address: {
						rules: [{
							required: true,
							errorMessage: '地址不能为空'
						}]
					},
					equname: {
						rules: [{
							required: true,
							errorMessage: '设备名称不能为空'
						}]
					},
					equtype: {
						rules: [{
							required: true,
							errorMessage: '设备类型不能为空'
						}]
					},
					description: {
						rules: [{
							required: true,
							errorMessage: '故障描述不能为空'
						}]
					},
				},
			}
		},
		onLoad() {},
		onShow() {
			this.getUserInfo()
			this.baseUrl = getBaseUrl();
		},
		methods: {
			getUserInfo: async function() {
				const result = await requestUtil({
					url: "/user/getUserInfo",
					method: 'get'
				});
				console.log("result=" + result.currentUser.nickName);
				this.userInfo = result.currentUser
			},
			// 设备类型下拉框改变事件
			change(e) {
				console.log("设备类型 => :", e);
				console.log("设备类型 => :", this.range[e].text);
			},
			submit(ref) {
				let _that = this
				this.$refs[ref].validate()
					.then(res => {
						console.log('success', res);
						console.log(_that.range[res.equtype].text);
						console.log('phone',res.phone)
						let form = {
							username: res.username,
							nickName: _that.userInfo.nickName,
							phone: res.phone,
							address: res.address,
							equname: res.equname,
							equtype: _that.range[res.equtype].text,
							description: res.description,
							image: _that.valiFormData.image,
							status: 1 // status = 1 表示新报修
						}
						let result = requestUtil({
							url: "/api/v1/report/addReport",
							data: form,
							method: "post"
						});
						
						// 提交成功清空表单
						_that.valiFormData = {
							username: '',
							phone: '',
							address: '',
							equname: '',
							equtype: '',
							description: '',
							image: '',
							status: 1
						}
						_that.valiFormData.image = ''
					}).catch(err => {
						console.log('err', err);
					})
			},
			selectReportFileFunc: function(e) {
				console.log(e.tempFilePaths[0])
				uni.uploadFile({
					header: {
						token: uni.getStorageSync("token")
					},
					url: getBaseUrl() + "/api/v1/report/uploadReportImage",
					filePath: e.tempFilePaths[0],
					name: "reportImage",
					success: (res) => {
						let result = JSON.parse(res.data);
						console.log(result)
						if (result.code == 200) {
							this.valiFormData.image = result.reportImageFileName;
							console.log(this.valiFormData.image);
						}
					}
				})
			},
		}
	}
</script>


<style lang="scss">
	@import "/common/css/iconfont.css";

	.container {
		.example {
			padding: 15px;
			background-color: #fff;

			.cover_img {
				.upload_img {
					border-radius: 5px;
					margin-top: 10rpx;
					width: 80%;
					height: 360rpx;
					background-color: white;
					display: flex;
					align-items: center;
					justify-content: center;

					.upload {
						margin: 10rpx;
						background-color: #f4f5f7;
						width: 80%;
						height: 80%;
						display: flex;
						align-items: center;
						justify-content: center;
					}
				}
			}
		}
	}

	.submit_btn {
		border-radius: 15px;
	}
</style>