<template>
	<uni-card :is-shadow="true" padding="0" spacing="0">
		<template v-slot:cover>
			<view class="custom-cover">
				<uv-image class="cover-image" mode="aspectFill" :showLoading="true"
					:src="reportObj.image" width="700rpx"
					height="700rpx"></uv-image>
				<view style="margin-top: 10rpx;" class="cover-content">
					<uni-section title="申请人" type="line">
						<template v-slot:right>
							{{reportObj.username}}
						</template>
					</uni-section>
					<uni-section title="联系方式" type="line">
						<template v-slot:right>
							{{reportObj.phone}}
						</template>
					</uni-section>
					<uni-section title="设备地址" type="line">
						<template v-slot:right>
							{{reportObj.address}}
						</template>
					</uni-section>
					<uni-section title="设备类型" type="line">
						<template v-slot:right>
							{{reportObj.equtype}}
						</template>
					</uni-section>
					<uni-section title="设备名称" type="line" >
						<template v-slot:right>
							{{reportObj.equname}}
						</template>
					</uni-section>
					<uni-section title="申请日期" type="line">
						<template v-slot:right>
							{{reportObj.createTime}}
						</template>
					</uni-section>
					<uni-section title="故障描述" type="line">
						<template v-slot:right>
							{{reportObj.description}}
						</template>
					</uni-section>	
				</view>
			</view>
		</template>

	</uni-card>

</template>

<script>
	import {
		getBaseUrl,
		requestUtil
	} from "../../utils/requestUtil.js"
	export default {
		data() {
			return {
				baseUrl: '',
				reportObj: {},
			}
		},
		methods: {
			getReportsList: async function(id) {
				const result = await requestUtil({
					url: "/api/v1/report/" + id,
					method: 'get'
				});
				this.reportObj = result.report
			}
		},
		onLoad: function(option) { //option为object类型，会序列化上个页面传递的参数
			console.log(option.id); //打印出上个页面传递的参数。
			this.baseUrl = getBaseUrl();
			this.getReportsList(option.id)

		},
		onShow(option) {
			this.getReportsList(option.id)
		}
	}
</script>

<style>

</style>